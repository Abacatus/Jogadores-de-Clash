package Jogadores_de_Clash.Jogador;

import Jogadores_de_Clash.States.StateLucas;

public class LucasXGamer {

    private int energia = 10;
    public int getEnergia(){
        return energia;
    }

    public void addEnergia(int quantidade) {
        energia += quantidade;

        if (energia > 10) {
            energia = 10;
        }
        if (energia < 0) {
            energia = 0;
        }
    }

    private StateLucas state = new LucasJogar(this);

    public void update(){
        state.execute();
    }

    public void mudarEstado(StateLucas state){
        if (this.state != null) {
            this.state.leave();
        }

        this.state = state;

        if (this.state != null) {
            this.state.enter();
        }
    }


}
