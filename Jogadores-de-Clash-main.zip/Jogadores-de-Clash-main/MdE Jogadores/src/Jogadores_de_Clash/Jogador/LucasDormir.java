package Jogadores_de_Clash.Jogador;

import Jogadores_de_Clash.States.StateLucas;

public class LucasDormir implements StateLucas {
    private LucasXGamer agente;
    public LucasDormir(LucasXGamer agente) {
        this.agente = agente;
    }

    public void enter(){
        System.out.println("LucasXGamer: eita que sono...");
    }

    public void execute(){
        agente.addEnergia(1);
        System.out.println("LucasXGamer está dormindo...");
        System.out.println("Energia: " + agente.getEnergia());

        if (agente.getEnergia() >= 10) {
            agente.mudarEstado(new LucasJogar(agente));
        }

    }

    public void leave(){
    }
}
