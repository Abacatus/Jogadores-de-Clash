package Jogadores_de_Clash;

import Jogadores_de_Clash.Jogador.Jogador;
import Jogadores_de_Clash.Jogador.LucasXGamer;

public class Main {
    public static void main(String[] args) {
        int loops = 50;

        Jogador jogador1 = new Jogador();
        LucasXGamer lucas = new LucasXGamer();

        while(loops > 0) {
            jogador1.update();
            lucas.update();

            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

            loops--;
        }
    }
}
